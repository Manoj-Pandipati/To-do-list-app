# To Do List – Task Manager

## Overview
A basic MERN stack To Do List application to manage tasks efficiently.

## Technologies Used
- MongoDB
- Express.js
- React.js
- Node.js

## Features
- Add, update, delete tasks
- Responsive UI
- REST API integration

## Folder Structure
- `/backend` – Node.js + Express server
- `/frontend` – React app placeholder

## How to Run
1. Run `npm install` inside `backend/`
2. Run `node server.js` to start backend
